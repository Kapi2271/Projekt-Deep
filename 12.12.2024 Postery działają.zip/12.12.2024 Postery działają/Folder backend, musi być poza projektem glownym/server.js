const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost', // Replace with your MySQL host
    user: 'root',      // Replace with your MySQL username
    password: '',      // Replace with your MySQL password
    database: 'projekt-deep' // Replace with your database name
});

db.connect((err) => {
    if (err) {
        console.log('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL');
});

// GET Mapping - Fetch all users
app.get('/items', (req, res) => {
    const sql = 'SELECT items.ID, items.name, items.price, items.typeID, users.username as username, users.discordName as dcName, types.typeName as itemType FROM items JOIN users on items.userID=users.ID JOIN types on items.typeID=types.ID;'; // Replace 'users' with your table name
    db.query(sql, (err, results) => {
        if (err) {
            res.status(500).send(err);
            return;
        }
        res.json(results);
    });
});

// // POST Mapping - Add a new user
// app.post('/items', (req, res) => {
//     const { name, email } = req.body; // Expecting name and email in request body
//     if (!name || !email) {
//         res.status(400).json({ error: 'Name and email are required' });
//         return;
//     }

//     const sql = 'INSERT INTO users (name, email) VALUES (?, ?)'; // Replace 'users' with your table name
//     db.query(sql, [name, email], (err, result) => {
//         if (err) {
//             res.status(500).send(err);
//             return;
//         }
//         res.json({ message: 'User added successfully', id: result.insertId });
//     });
// });

// Start the server
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});