import './App.css'
import Header from './components/header/Header'
import Title from './components/body/Title'
import Poster from './components/body/Poster';
import Note from "./components/images/note.png"
import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/items').then(response => {
            setItems(response.data);
        }).catch(error => {
            console.error('There was an error fetching the data!', error);
        });
  }, []);

  const [users, setUsers] = userState([]);
  useEffect(() => {
    axios.get('http://localhost:5000/users').then(response => {
            setUsers(response.data);
        }).catch(error => {
            console.error('There was an error fetching the data!', error);
        });
  }, []);


  return (
    <>
        
      <Header/>
      <Title/>
      <main>
          {items.map(index => (
            <section className="poster" id="poster" key={index.ID}>
              <p className="itemName" id="itemName">{index.name}</p>
              <br/>
              <img src={index.image} alt="item" className="itemImage" id="itemImage"/>
              <br/>
              {users.map(user => (
                 <p className="owner" id="owner"></p>
              ))}
             
              <br/>
              <p className="cost" id="cost">{index.price}<img className="note" id="note" src={Note} alt="Note"/>
              </p>
            </section>
          ))}
      </main>
    </>
    
  )
}

export default App
