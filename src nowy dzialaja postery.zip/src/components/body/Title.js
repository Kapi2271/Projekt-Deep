import Romb from '../images/romb.png'

function Title() {
  return (
    <section>
        <img className="rombus" id="rombus" alt="rombus" src={Romb}/>
        <p className="shopHeader" id="shopHeader">SHOP</p>
        <img className="rombus" id="rombus" alt="rombus" src={Romb}></img>
    </section>
  )
}

export default Title