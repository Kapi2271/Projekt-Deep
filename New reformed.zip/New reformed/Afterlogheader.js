import { Link } from 'react-router'
import Logo from '../images/logo.png'

// import Lupa from '../images/lupa.png'
// import { useState } from 'react'

const Afterlogheader = () => {

    function handleClick(e){
        let res = window.confirm("Are you sure you want to log out?")
        if (res){
            return;
        } else e.preventDefault();
    }

  return (
    <header>
      <img src={Logo} alt="Deepwoken logo" className="logo" id="logo"/>
        <h1 id='titleDeep'><Link to='/logged'>Deepwoken</Link></h1>
        
        <div id='loginButtons'>
          <Link to="/" onClick={handleClick}>Log Out</Link>
        </div>
    </header>
  )
}

export default Afterlogheader