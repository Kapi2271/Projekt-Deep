import './App.css'
import Afterlogheader from './components/header/Afterlogheader'
import Title from './components/body/Title'
import Note from "./components/images/note.png"
import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Afterlog() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/items').then(response => {
            setItems(response.data);
        }).catch(error => {
            console.error('There was an error fetching the data!', error);
        });
  }, []);


  return (
    <>
      <Afterlogheader/>
      <Title/>
      <main>
          {items.map(item => (
            <section className="poster" id="poster" key={item.ID}>
              <p className="itemName" id="itemName">{item.name}</p>
              <br/>
              <img src={item.image} alt="itemImage" className="itemImage" id="itemImage"/>
              <br/>
              <p className="itemType" id="itemType">Type: {item.itemType}</p>
              <p className="owner" id="owner" title="It's a discord nick.&#013;You can contact the player either way.">Player: {item.dcName}</p>
              <p className="cost" id="cost">Price: {item.price}<img className="note" id="note" src={Note} alt="Note"/>
              </p>
            </section>
          ))}
      </main>
    </>
  )
}

export default Afterlog
